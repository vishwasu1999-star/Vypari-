'use strict';
const jwt    = require('jsonwebtoken');
const { query } = require('../config/db');
const { AppError } = require('./errorHandler');

// ============================================================
// authenticate — verify Bearer token, attach req.user
// ============================================================
const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) {
      return next(new AppError('Authentication required', 401));
    }

    const token   = header.slice(7);
    let decoded;

    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtErr) {
      if (jwtErr.name === 'TokenExpiredError') {
        return next(new AppError('Token expired — please refresh', 401));
      }
      return next(new AppError('Invalid authentication token', 401));
    }

    // Verify user still exists and is active
    const result = await query(
      'SELECT id, name, email, is_active FROM users WHERE id = $1',
      [decoded.userId]
    );

    if (!result.rows.length) {
      return next(new AppError('User account not found', 401));
    }
    if (!result.rows[0].is_active) {
      return next(new AppError('User account is deactivated', 401));
    }

    req.user = result.rows[0];
    next();
  } catch (err) {
    next(err);
  }
};

// ============================================================
// requireBusiness — verify user owns the requested business
// Attaches req.businessId to the request
// ============================================================
const requireBusiness = async (req, res, next) => {
  try {
    const businessId = req.params.businessId
      || req.body.businessId
      || req.query.businessId
      || req.headers['x-business-id'];

    if (!businessId) {
      return next(new AppError('businessId is required', 400));
    }

    const result = await query(
      'SELECT id FROM businesses WHERE id = $1 AND owner_id = $2 AND is_active = TRUE',
      [businessId, req.user.id]
    );

    if (!result.rows.length) {
      return next(new AppError('Business not found or access denied', 403));
    }

    req.businessId = businessId;
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { authenticate, requireBusiness };
