'use strict';
const { query }    = require('../config/db');
const { AppError } = require('./errorHandler');

// ============================================================
// checkAuditLock
// Middleware factory — extracts the transaction date from
// req.body[dateField] and blocks if period is locked.
//
// Usage in routes:
//   router.post('/', auth, requireBusiness, checkAuditLock('invoiceDate'), ctrl.create)
// ============================================================
const checkAuditLock = (dateField = 'date') => async (req, res, next) => {
  try {
    const dateValue = req.body?.[dateField] || req.body?.date || req.body?.invoiceDate;

    if (!dateValue) return next(); // no date → let controller validate

    const result = await query(
      'SELECT lock_date FROM businesses WHERE id=$1',
      [req.businessId]
    );
    const lockDate = result.rows[0]?.lock_date;

    if (!lockDate) return next(); // no lock set

    const txDate   = new Date(dateValue);
    const lockDt   = new Date(lockDate);

    if (txDate <= lockDt) {
      return next(new AppError(
        `Period is locked. Transactions on or before ${lockDate} cannot be created or edited. ` +
        `Contact your accountant to advance the lock date.`,
        423  // 423 Locked
      ));
    }

    next();
  } catch (err) {
    next(err);
  }
};

// ============================================================
// checkAuditLockForId
// For updates/deletes — fetches the existing record's date
// ============================================================
const checkAuditLockForRecord = (table, dateColumn = 'date') => async (req, res, next) => {
  try {
    const id = req.params.id;
    if (!id) return next();

    const result = await query(
      'SELECT lock_date FROM businesses WHERE id=$1',
      [req.businessId]
    );
    const lockDate = result.rows[0]?.lock_date;
    if (!lockDate) return next();

    const rec = await query(
      `SELECT ${dateColumn} AS record_date FROM ${table} WHERE id=$1`,
      [id]
    );
    if (!rec.rows.length) return next();

    const recDate = new Date(rec.rows[0].record_date);
    const lockDt  = new Date(lockDate);

    if (recDate <= lockDt) {
      return next(new AppError(
        `This record is in a locked period (≤ ${lockDate}) and cannot be modified.`,
        423
      ));
    }

    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { checkAuditLock, checkAuditLockForRecord };
