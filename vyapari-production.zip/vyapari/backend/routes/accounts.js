'use strict';
const express = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const ctrl    = require('../controllers/accountController');
const router  = express.Router({ mergeParams: true });

router.use(authenticate, requireBusiness);
router.get ('/',    ctrl.listAccounts);
router.post('/',    ctrl.createAccount);
router.get ('/:id', ctrl.getAccount);
router.put ('/:id', ctrl.updateAccount);

module.exports = router;
