'use strict';
const express = require('express');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { query } = require('../config/db');
const router  = express.Router();

// POST /api/sync  — receive offline queue from client, apply in order
router.post('/', authenticate, asyncHandler(async (req, res) => {
  const { businessId, items } = req.body;
  if (!items?.length) return res.json({ synced: 0 });

  // Verify business ownership
  const biz = await query('SELECT id FROM businesses WHERE id=$1 AND owner_id=$2', [businessId, req.user.id]);
  if (!biz.rows.length) return res.status(403).json({ error: 'Access denied' });

  let synced = 0;
  const errors = [];

  for (const item of items) {
    try {
      await query(
        `INSERT INTO sync_queue (business_id, client_id, entity, operation, entity_id, local_id, payload, synced, synced_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,TRUE,NOW())
         ON CONFLICT DO NOTHING`,
        [businessId, item.clientId || 'unknown', item.entity, item.operation, item.entityId || null, item.localId || null, JSON.stringify(item.payload)]
      );
      synced++;
    } catch (err) {
      errors.push({ localId: item.localId, error: err.message });
    }
  }

  res.json({ synced, errors });
}));

module.exports = router;
