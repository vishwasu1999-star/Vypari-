'use strict';
const express = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const ctrl    = require('../controllers/itemController');
const router  = express.Router({ mergeParams: true });

router.use(authenticate, requireBusiness);
router.get ('/',             ctrl.listItems);
router.post('/',             ctrl.createItem);
router.get ('/:id',          ctrl.getItem);
router.put ('/:id',          ctrl.updateItem);
router.delete('/:id',        ctrl.deleteItem);
router.patch('/:id/stock',   ctrl.adjustStock);

module.exports = router;
