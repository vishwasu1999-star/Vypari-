'use strict';
const express = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const ctrl    = require('../controllers/reportController');
const router  = express.Router({ mergeParams: true });

router.use(authenticate, requireBusiness);
router.get('/dashboard',               ctrl.dashboard);
router.get('/trial-balance',           ctrl.trialBalance);
router.get('/profit-loss',             ctrl.profitLoss);
router.get('/balance-sheet',           ctrl.balanceSheet);
router.get('/day-book',                ctrl.dayBook);
router.get('/gst',                     ctrl.gstReport);
router.get('/cash-book',               ctrl.cashBook);
router.get('/account-ledger/:accountId', ctrl.accountLedger);

module.exports = router;
