'use strict';
const express  = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const ctrl     = require('../controllers/businessController');
const router   = express.Router();

router.get ('/',                        authenticate, ctrl.listBusinesses);
router.post('/',                        authenticate, ctrl.createBusiness);
router.get ('/:businessId',             authenticate, requireBusiness, ctrl.getBusiness);
router.put ('/:businessId',             authenticate, requireBusiness, ctrl.updateBusiness);

module.exports = router;
