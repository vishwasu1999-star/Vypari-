'use strict';
const express = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const { attachRole }  = require('../middleware/rbac');
const ctrl    = require('../controllers/settingsController');
const router  = express.Router({ mergeParams: true });

router.use(authenticate, requireBusiness, attachRole);

router.get  ('/',                     ctrl.getSettings);
router.patch('/lock-date',            ctrl.setLockDate);
router.patch('/stock',                ctrl.updateStockSettings);
router.patch('/fy',                   ctrl.updateFYSettings);
router.post ('/members',              ctrl.inviteMember);
router.delete('/members/:userId',     ctrl.removeMember);
router.post ('/fy/carry-forward',     ctrl.carryForwardBalances);

module.exports = router;
