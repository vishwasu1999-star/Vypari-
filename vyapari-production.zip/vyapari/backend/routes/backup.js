'use strict';
const express = require('express');
const { authenticate, requireBusiness } = require('../middleware/auth');
const { requireAnyRole, attachRole }    = require('../middleware/rbac');
const ctrl    = require('../controllers/backupController');
const router  = express.Router({ mergeParams: true });

router.use(authenticate, requireBusiness, attachRole);

// Only owner/accountant can create backups; only owner can restore
router.get ('/',        requireAnyRole('owner', 'accountant'), ctrl.listBackups);
router.post('/create',  requireAnyRole('owner', 'accountant'), ctrl.createBackup);
router.post('/restore', requireAnyRole('owner'),               ctrl.restoreBackup);

module.exports = router;
